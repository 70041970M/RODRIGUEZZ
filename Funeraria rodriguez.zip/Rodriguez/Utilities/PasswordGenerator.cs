﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rodriguez.Utilities
{
    class PasswordGenerator
    {


        public static string getPassword(int longitud)
        {
            string cadenaEncriptada = "";

            try
            {

                int numero = (new Random()).Next(100, 9000);
                int workFactor = 5;
                cadenaEncriptada = BCrypt.Net.BCrypt.HashPassword((numero.ToString()), BCrypt.Net.BCrypt.GenerateSalt(workFactor));

                cadenaEncriptada = cadenaEncriptada.Substring(10, longitud);
            }
            catch (Exception)
            {

                throw;
            }



            return cadenaEncriptada;
        }












    }
}
