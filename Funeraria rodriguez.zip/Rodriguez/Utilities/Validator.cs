﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rodriguez.Utilities
{
    class Validator
    {
        public static bool isEmail(string email)
        {
            if (string.IsNullOrEmpty(email)) return true;

            System.Text.RegularExpressions.Regex emailRegex = new System.Text.RegularExpressions.Regex("^(?<user>[^@]+)@(?<host>.+)$");
            System.Text.RegularExpressions.Match emailMatch = emailRegex.Match(email);
            return emailMatch.Success;
        }


        public static bool isDNI(string dni)
        {
            if (string.IsNullOrEmpty(dni)) return true;

            System.Text.RegularExpressions.Regex DNIRegex = new System.Text.RegularExpressions.Regex("^\\d+$");
            System.Text.RegularExpressions.Match DNIMatch = DNIRegex.Match(dni);
            return (DNIMatch.Success && dni.Length == 8);
        }

        public static bool isRUC(string ruc)
        {
            if (string.IsNullOrEmpty(ruc)) return true;

            System.Text.RegularExpressions.Regex RUCRegex = new System.Text.RegularExpressions.Regex("^\\d+$");
            System.Text.RegularExpressions.Match RUCMatch = RUCRegex.Match(ruc);
            return (RUCMatch.Success && ruc.Length == 11);
        }

        public static bool isNumero(string numero)
        {
            if (string.IsNullOrEmpty(numero)) return true;

            System.Text.RegularExpressions.Regex numeroRegex = new System.Text.RegularExpressions.Regex("^\\d+$");
            System.Text.RegularExpressions.Match numeroMatch = numeroRegex.Match(numero);
            return numeroMatch.Success;
        }


        public static bool isDecimal(string numeroDecimal)
        {
            System.Text.RegularExpressions.Regex numeroDecimalRegex = new System.Text.RegularExpressions.Regex("^[0-9]+([.][0-9]+)?$");
            System.Text.RegularExpressions.Match numeroDecimalMatch = numeroDecimalRegex.Match(numeroDecimal);
            return numeroDecimalMatch.Success;
        }

        //----metodo para alidar ingreso de numeros decimales------------------
        public static void isNumeroDecimalPulsado(System.Windows.Forms.TextBox CajaTexto, System.Windows.Forms.KeyPressEventArgs e)
        {


            if (char.IsDigit(e.KeyChar))
            {

                e.Handled = false;
            }
            else if (char.IsControl(e.KeyChar))
            {
                e.Handled = false;
            }
            else if (((e.KeyChar == '.') && (CajaTexto.Text.IndexOf(".") != -1)))
            {

                e.Handled = true;
            }
            else if (e.KeyChar == '.')
            {

                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }

        }

        //---------------metodo para ingresar solo digitos--------------------------
        public static void isDigitoPulsado(System.Windows.Forms.KeyPressEventArgs e)
        {
            if ((!Char.IsNumber((e.KeyChar)) && (Convert.ToInt32((e.KeyChar)) != 8)))
            {
                e.Handled = true;
            }

        }



    }
}
