﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rodriguez.Utilities
{
    class Logger
    {
        private ILog log;

        public Logger()
        {

            log4net.Config.XmlConfigurator.Configure();
            log = LogManager.GetLogger("My app");

        }

        public void setException(Exception ex)
        {
            log.Error(ex.Message + "-" + ex.StackTrace);

        }


    }
}
