﻿namespace Rodriguez {
    
    
    public partial class frodriguezDataSet1 {
        partial class reporteClientesEmpresaDataTable
        {
        }
    
        partial class reporteTopProductosDataTable
        {
        }
    
        partial class reporteStockProductosDataTable
        {
        }
    
        partial class reporteFacturaDataTable
        {
        }
    
        partial class reporteEmpleadoDataTable
        {
        }
    
        partial class reporteProductosDataTable
        {
        }
    }
}
