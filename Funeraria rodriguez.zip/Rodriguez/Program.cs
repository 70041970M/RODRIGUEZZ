﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Rodriguez.Vista;
using Rodriguez.Entitites;




namespace Rodriguez
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //Application.Run(new FrmMantenimientoEmpleado());

            //------------------------------------------------
            V_Login frm = new V_Login();
            frm.ShowDialog();

            if (frm.DialogResult == DialogResult.OK)
            {

                if (EmpleadoLogueado.cargo.CompareTo("ADMINISTRADOR") == 0)
                {

                    Application.Run(new V_MenuAdministrador());

                }
                else if (EmpleadoLogueado.cargo.CompareTo("VENDEDOR") == 0)
                {

                    Application.Run(new V_MenuVendedor());
                }


                frm.Close();



            }

            //    -----------------------
        }
    }

}