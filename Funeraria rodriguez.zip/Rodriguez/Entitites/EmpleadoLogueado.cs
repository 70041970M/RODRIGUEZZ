﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rodriguez.Entitites
{
    class EmpleadoLogueado
    {


        public static Int16 idempleado;
        public static string nombre;
        public static string apellido;
        public static string direccion;
        public static string cargo;
        public static string telefono;
        public static string dni;
        public static DateTime fechanacimiento;
        public static DateTime fechaentrada;
        public static string contraseña;
      //  public static bool activo;









    }
}
